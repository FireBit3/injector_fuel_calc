# Fuel Injector Calculator

A web-based app to calculate base pulse width and injector duty cycle based on engine parameters using Streamlit.